CREATE TRIGGER dbo.TR_WorkshopParticipants_CancelledReservation
  ON dbo.WorkshopParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM inserted
    JOIN WorkshopReservations AS wr
      ON inserted.WorkshopReservationID = wr.WorkshopReservationID
    WHERE wr.IsCancelled = 1
  )
  BEGIN

    ROLLBACK
    ;THROW 60000, 'Cannot add new participant to cancelled WorkshopReservation', 1

  END

END
GO
