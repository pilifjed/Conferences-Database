CREATE TRIGGER dbo.TR_DayPrices_IllegalStartDate
ON dbo.DayPrices
  AFTER INSERT, UPDATE 
AS
BEGIN 
  
  IF EXISTS(
    SELECT *
    FROM inserted
    JOIN ConferenceDays AS cd 
      ON cd.ConferenceDayID = inserted.ConferenceDayID
    WHERE cd.Date < inserted.StartDate
  )
  BEGIN
    ROLLBACK
    ;THROW 60000, 'Cannot add DayPrice with StartDate later than ConferenceDay.Date', 1
  END
  
END
GO
