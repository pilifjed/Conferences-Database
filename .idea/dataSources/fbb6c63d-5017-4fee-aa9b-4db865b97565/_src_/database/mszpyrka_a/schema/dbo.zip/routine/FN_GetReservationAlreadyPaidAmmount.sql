CREATE FUNCTION dbo.FN_GetReservationAlreadyPaidAmmount(@ReservationID INT)
  RETURNS INT
AS
BEGIN

  RETURN isnull((
    SELECT sum(AmmountPaid)
    FROM Payments
    WHERE @ReservationID = ReservationID
  ), 0)

END
GO
