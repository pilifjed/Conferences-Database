CREATE PROCEDURE dbo.PR_AddConference
  @Name NVARCHAR(120),
  @Acronym NVARCHAR(15),
  @Country NVARCHAR(40),
  @City NVARCHAR(40),
  @Venue NVARCHAR(120)
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
      INSERT INTO Conferences (Name, Acronym, Country, City, Venue)
        VALUES (@Name, @Acronym, @Country, @City, @Venue)
    END TRY
    BEGIN CATCH
      DECLARE @errormsg NVARCHAR(2048)
      = 'An error ocurred while adding conference. Error message: ' + ERROR_MESSAGE();
      ;THROW 52000, @errormsg, 1
    END CATCH
END
GO
