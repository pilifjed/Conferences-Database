CREATE TRIGGER dbo.TR_ConferenceDays_WorkshopsCollidingAfterUpdate
	ON dbo.ConferenceDays
	AFTER UPDATE
AS
BEGIN

	IF dbo.FN_AnyWorkshopsColliding() = 1
	BEGIN
		ROLLBACK
		;THROW 6000, 'Changing given ConferenceDay.Date will cause some participant''s workshops collision', 1
	END

END
GO
