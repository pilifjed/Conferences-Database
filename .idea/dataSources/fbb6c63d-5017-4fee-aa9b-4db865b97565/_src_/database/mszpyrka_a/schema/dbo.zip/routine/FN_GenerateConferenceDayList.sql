CREATE FUNCTION dbo.FN_GenerateConferenceDayList(@ConferenceDayID INT)
  RETURNS TABLE
AS
  RETURN (
  SELECT p.FirstName, p.LastName
  FROM Participants p
  WHERE p.ParticipantID
        IN(
          SELECT cp.ParticipantID
          FROM ConferenceParticipants cp
          WHERE cp.ConfDayReservationID
                IN(
                  SELECT cdr.ConfDayReservationID
                  FROM ConfDayReservations cdr
                  WHERE IsCancelled=0 AND ConferenceDayID=@ConferenceDayID
                )
        )
  )
GO
