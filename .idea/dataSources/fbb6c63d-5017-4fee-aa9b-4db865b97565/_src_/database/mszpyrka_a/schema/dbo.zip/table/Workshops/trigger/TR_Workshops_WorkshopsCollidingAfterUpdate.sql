CREATE TRIGGER dbo.TR_Workshops_WorkshopsCollidingAfterUpdate
	ON dbo.Workshops
	AFTER UPDATE
AS
BEGIN

	IF dbo.FN_AnyWorkshopsColliding() = 1
	BEGIN
		ROLLBACK
		;THROW 6000, 'Changing given workshop time range will cause some participant''s workshops collision', 1
	END

END
GO
