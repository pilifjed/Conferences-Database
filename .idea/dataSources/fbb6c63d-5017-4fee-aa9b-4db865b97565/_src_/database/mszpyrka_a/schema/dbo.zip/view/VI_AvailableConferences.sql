CREATE VIEW dbo.VI_AvailableConferences
AS
  SELECT *,dbo.FN_GetConferenceStartDate(c.ConferenceID) as ConferenceStartDate, dbo.FN_GetConfDayFreePlaces(c.ConferenceID) as FreePlaces
  FROM Conferences c
  WHERE c.ConferenceID IN(SELECT ConferenceID FROM VI_AvailableConfDays)
GO
