CREATE PROCEDURE dbo.PR_RemoveReservation
  @ReservationID INT
AS
BEGIN
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM Reservations
        WHERE ReservationID=@ReservationID
      )
      BEGIN
        ;THROW 61001, 'Given ClientID does not exist', 1
      END
      IF @ReservationID IS NOT NULL
        BEGIN
          DELETE  FROM Reservations
                  WHERE ReservationID=@ReservationID
        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while deleting reservation: ' + ERROR_MESSAGE ();
      THROW 61000, @errorMsg, 1
    END CATCH
END
GO
