CREATE VIEW dbo.VI_WorkshopPlaces
AS
  SELECT w.WorkshopID,w.StartTime,w.EndTime,
    w.MaxParticipantsNumber as NumberOfPlaces,
    dbo.FN_GetWorkshopBookedPlaces(w.WorkshopID) as NumberOfBookedPlaces,
    dbo.FN_GetWorkshopFreePlaces(w.WorkshopID) as NumberOfFreePlaces
  FROM dbo.Workshops w
GO
