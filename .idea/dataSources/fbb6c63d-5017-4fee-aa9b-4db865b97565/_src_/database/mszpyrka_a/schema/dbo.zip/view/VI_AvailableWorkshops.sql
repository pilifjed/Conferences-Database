CREATE VIEW dbo.VI_AvailableWorkshops
AS
  SELECT w.*
  FROM dbo.Workshops w
  WHERE dbo.FN_GetWorkshopFreePlaces(w.WorkshopID)>0
        AND w.ConferenceDayID IN(SELECT ConferenceDayID FROM VI_AvailableConfDays)
GO
