CREATE VIEW dbo.VI_AvailableConfDays
AS
  SELECT c.*
  FROM dbo.ConferenceDays c
  WHERE dbo.FN_GetConfDayFreePlaces(c.ConferenceDayID)>0 
        AND (SELECT Date 
             FROM ConferenceDays 
             WHERE c.ConferenceDayID = ConferenceDayID) > GETDATE()
GO
