CREATE VIEW dbo.VI_ConferenceDayPlaces
AS
  SELECT c.ConferenceID,c.ConferenceDayID,c.Date,
    c.MaxParticipantsNumber as NumberOfPlaces,
    dbo.FN_GetConfDayBookedPlaces(c.ConferenceDayID) as NumberOfBookedPlaces,
    dbo.FN_GetConfDayFreePlaces(c.ConferenceDayID) as NumberOfFreePlaces
  FROM dbo.ConferenceDays c
GO
