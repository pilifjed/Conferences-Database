CREATE TRIGGER TR_Workshops_CannotDecreasePlaces
	ON dbo.Workshops
	AFTER UPDATE
AS
BEGIN

	IF EXISTS(
		SELECT *
		FROM Workshops
		WHERE dbo.FN_GetWorkshopFreePlaces (WorkshopID) < 0
	)
	BEGIN
		ROLLBACK
		;THROW 60000, 'Registered participants number exceeds new places limit for updated Workshop', 1
	END

END
GO
