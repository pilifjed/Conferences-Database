CREATE FUNCTION dbo.FN_GetWorkshopFreePlaces(@WorkshopID INT)
  RETURNS INT
AS BEGIN

  DECLARE @BookedPlaces INT = isnull(dbo.FN_GetWorkshopBookedPlaces(@WorkshopID), 0)

  RETURN (
    SELECT MaxParticipantsNumber
    FROM Workshops
    WHERE @WorkshopID = WorkshopID
  ) - @BookedPlaces

END
GO
