CREATE PROCEDURE dbo.PR_AddReservation
  @ClientID INT,
  @BookingDate DATE
AS
BEGIN
    SET NOCOUNT OFF
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM Clients
        WHERE @ClientID = ClientID
      )
      BEGIN
        ;THROW 60000, 'Given ClientID does not exist', 1
      END

      INSERT INTO dbo.Reservations(ClientID, BookingDate)
        VALUES (@ClientID, @BookingDate)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding reservation: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
