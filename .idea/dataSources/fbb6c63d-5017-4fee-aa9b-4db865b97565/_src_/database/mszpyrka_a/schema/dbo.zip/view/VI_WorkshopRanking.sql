CREATE VIEW dbo.VI_WorkshopRanking
AS
  SELECT w.*, (dbo.FN_GetWorkshopBookedPlaces(w.WorkshopID)*100/w.MaxParticipantsNumber) AS Interest
  FROM dbo.Workshops w
GO
