CREATE TRIGGER dbo.TR_WorkshopReservations_IllegalParticipantsNumber
  ON dbo.WorkshopReservations
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM inserted
    JOIN ConfDayReservations AS cdr
      ON cdr.ConfDayReservationID = inserted.ConfDayReservationID
    WHERE inserted.ParticipantsNumber > cdr.ParticipantsNumber
  )
  BEGIN
    ROLLBACK 
    ;THROW 60000, 'Cannot book more places for workshop than for corelated conference day', 1
  END

END
GO
