CREATE PROCEDURE dbo.PR_RemoveWorkshopParticipant
  @ConferenceParticipantID INT,
  @WorkshopReservationID INT
AS
BEGIN
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM WorkshopParticipants
        WHERE ConferenceParticipantID=@ConferenceParticipantID OR WorkshopReservationID=@WorkshopReservationID
      )
      BEGIN
        ;THROW 61001, 'Given ConferenceParticipantID and WorkshopID does not exist', 1
      END
      IF @ConferenceParticipantID IS NOT NULL
        BEGIN
          DELETE  FROM WorkshopParticipants
                  WHERE ConferenceParticipantID=@ConferenceParticipantID
        END
      IF @WorkshopReservationID IS NOT NULL
        BEGIN
          DELETE  FROM WorkshopParticipants 
                  WHERE WorkshopReservationID=@WorkshopReservationID
        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while deleting workshopParticipant: ' + ERROR_MESSAGE ();
      THROW 61000, @errorMsg, 1
    END CATCH
END
GO
