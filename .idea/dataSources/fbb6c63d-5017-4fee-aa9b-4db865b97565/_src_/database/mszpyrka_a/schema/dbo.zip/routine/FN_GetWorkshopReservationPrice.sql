CREATE FUNCTION dbo.FN_GetWorkshopReservationPrice(@WorkshopReservationID INT)
  RETURNS INT
AS BEGIN

  RETURN (
    SELECT WR.ParticipantsNumber * W.Price
    FROM WorkshopReservations AS WR
    JOIN Workshops AS W
      ON WR.WorkshopID = W.WorkshopID
    WHERE @WorkshopReservationID = WR.WorkshopReservationID
  )
END
GO
