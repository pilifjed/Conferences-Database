CREATE FUNCTION dbo.FN_GetReservationTotalPrice(@ReservationID INT)
  RETURNS INT
AS BEGIN

  DECLARE @TotalConfDayReservationsPrice INT, @TotalWorkshopReservationsPrice INT

  SET @TotalConfDayReservationsPrice = (

    SELECT sum(ConfDayReservationPrice)
    FROM (
      SELECT dbo.FN_GetConfDayReservationPrice(ConfDayReservationID) AS ConfDayReservationPrice
      FROM ConfDayReservations
      WHERE ReservationID = @ReservationID
    ) t
  )

  SET @TotalWorkshopReservationsPrice = (
    SELECT sum(WorkshopReservationPrice)
    FROM (
      SELECT dbo.FN_GetWorkshopReservationPrice(WorkshopReservationID) AS WorkshopReservationPrice
      FROM WorkshopReservations
      WHERE ConfDayReservationID IN (
        SELECT ConfDayReservationID
        FROM ConfDayReservations
        WHERE @ReservationID = ReservationID
      )
    ) t
  )

  RETURN isnull(@TotalConfDayReservationsPrice, 0) + isnull(@TotalWorkshopReservationsPrice, 0)
END
GO
