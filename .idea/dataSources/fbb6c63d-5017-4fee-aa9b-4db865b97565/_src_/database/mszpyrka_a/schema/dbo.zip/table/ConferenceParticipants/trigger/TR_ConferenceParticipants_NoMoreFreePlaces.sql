CREATE TRIGGER dbo.TR_ConferenceParticipants_NoMoreFreePlaces
  ON dbo.ConferenceParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

    IF EXISTS(
      SELECT *
      FROM inserted AS i
      JOIN ConfDayReservations AS CDR
      ON i.ConfDayReservationID = CDR.ConfDayReservationID
      WHERE dbo.FN_GetConfDayReservationSignedParticipantsNumber(i.ConfDayReservationID) > CDR.ParticipantsNumber
    )
    BEGIN
      ROLLBACK
      ;THROW 60000, 'No more free places for given ConfDayReservationID', 1
    END

    IF EXISTS(
      SELECT *
      FROM inserted AS i
      JOIN ConfDayReservations AS CDR
      ON i.ConfDayReservationID = CDR.ConfDayReservationID
      WHERE dbo.FN_GetConfDayReservationSignedStudentsNumber(i.ConfDayReservationID) > CDR.StudentsNumber
    )
    BEGIN
      ROLLBACK 
      ;THROW 60000, 'No more free student places for given ConfDayReservationID', 1
    END
END
GO
