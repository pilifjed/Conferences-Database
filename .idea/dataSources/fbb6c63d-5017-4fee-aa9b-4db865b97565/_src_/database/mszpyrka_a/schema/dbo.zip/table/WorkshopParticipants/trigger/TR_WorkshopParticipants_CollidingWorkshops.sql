CREATE TRIGGER TR_WorkshopParticipants_CollidingWorkshops
ON dbo.WorkshopParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM inserted
    JOIN ConferenceParticipants AS cp
      ON inserted.ConferenceParticipantID = cp.ConferenceParticipantID
    WHERE dbo.FN_ParticipantWorkshopsColliding (cp.ParticipantID) = 1
  )
  BEGIN

    ROLLBACK
    ;THROW 60000, 'Cannot add workshopParticipant because of colliding workshops', 1

  END

END
GO
