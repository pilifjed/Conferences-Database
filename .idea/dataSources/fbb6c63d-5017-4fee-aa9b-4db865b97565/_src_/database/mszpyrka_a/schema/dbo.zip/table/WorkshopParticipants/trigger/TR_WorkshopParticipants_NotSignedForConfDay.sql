CREATE TRIGGER TR_WorkshopParticipants_NotSignedForConfDay
ON dbo.WorkshopParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM WorkshopParticipants AS wp 
    JOIN ConferenceParticipants AS cp 
      ON wp.ConferenceParticipantID = cp.ConferenceParticipantID
    JOIN ConfDayReservations AS cdr 
      ON cp.ConfDayReservationID = cdr.ConfDayReservationID
    JOIN WorkshopReservations AS wr 
      ON wp.WorkshopReservationID = wr.WorkshopReservationID
    WHERE wr.ConfDayReservationID <> cdr.ConfDayReservationID
  )
  BEGIN

    ROLLBACK
    ;THROW 60000, 'Tried do add WorkshopParticipants to WorkshopReservation, who is not signed for corelated ConfDayReservation', 1

  END

END
GO
