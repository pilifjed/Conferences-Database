CREATE FUNCTION FN_AnyWorkshopsColliding()
  RETURNS BIT
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM Participants
    WHERE dbo.FN_ParticipantWorkshopsColliding (ParticipantID) = 1
  )
  BEGIN
    RETURN 1
  END

  RETURN 0

END
GO
