CREATE FUNCTION FN_GenerateWorkshopsList(@WorkshopID INT)
  RETURNS TABLE
AS
  RETURN (
  SELECT p.FirstName, p.LastName
  FROM Participants p
  WHERE p.ParticipantID
        IN(
          SELECT cp.ParticipantID
          FROM ConferenceParticipants cp
          WHERE cp.ConferenceParticipantID
                IN(
                  SELECT cdr.ConferenceParticipantID
                  FROM WorkshopParticipants cdr
                  WHERE WorkshopID=@WorkshopID
                )
        )
  )
GO
