CREATE FUNCTION dbo.FN_GetWorkshopReservationSignedParticipantsNumber(@WorkshopReservationID INT)
  RETURNS INT
AS BEGIN
  RETURN (
    SELECT count(*)
    FROM dbo.WorkshopReservations AS WR
    JOIN WorkshopParticipants AS WP
      ON WR.WorkshopReservationID = WP.WorkshopReservationID
    WHERE @WorkshopReservationID = WR.WorkshopReservationID
  )
END
GO
