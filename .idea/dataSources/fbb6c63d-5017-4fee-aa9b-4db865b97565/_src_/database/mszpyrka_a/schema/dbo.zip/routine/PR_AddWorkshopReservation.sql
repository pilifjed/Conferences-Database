CREATE PROCEDURE dbo.PR_AddWorkshopReservation
  @WorkshopID INT,
  @ConfDayReservationID INT,
  @ParticipantsNumber INT
AS
BEGIN
    SET NOCOUNT OFF
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM ConfDayReservations
        WHERE @ConfDayReservationID = ConfDayReservationID
      )
      BEGIN
        ;THROW 60000, 'Given ConfDayReservationID does not exist', 1
      END

      IF NOT EXISTS(
        SELECT *
        FROM Workshops
        WHERE @WorkshopID = WorkshopID
      )
        BEGIN
        ;THROW 60000, 'Given WorkshopID does not exist', 1
      END

      INSERT INTO dbo.WorkshopReservations(WorkshopID, ConfDayReservationID, ParticipantsNumber)
        VALUES (@WorkshopID, @ConfDayReservationID, @ParticipantsNumber)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding workshopReservation: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
