CREATE PROCEDURE dbo.PR_CancelReservation
  @ReservationID INT
AS
BEGIN
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM Reservations
        WHERE ReservationID=@ReservationID
      )
      BEGIN
        ;THROW 61001, 'Given ReservationID does not exist', 1
      END
      IF @ReservationID IS NOT NULL
        BEGIN
          UPDATE Reservations
                SET IsCancelled=1 WHERE ReservationID=@ReservationID

          UPDATE ConfDayReservations
            SET IsCancelled=1
          WHERE @ReservationID = ReservationID

          UPDATE WorkshopReservations
            SET IsCancelled=1
          WHERE ConfDayReservationID IN (
          SELECT ConfDayReservationID
            FROM ConfDayReservations
            WHERE ReservationID = @ReservationID
        )

        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while cancelling reservation: ' + ERROR_MESSAGE ();
      THROW 61000, @errorMsg, 1
    END CATCH
END
GO
