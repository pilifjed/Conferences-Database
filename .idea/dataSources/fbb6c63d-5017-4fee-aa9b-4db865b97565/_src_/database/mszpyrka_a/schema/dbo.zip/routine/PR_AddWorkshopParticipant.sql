CREATE PROCEDURE dbo.PR_AddWorkshopParticipant
  @WorkshopReservationID INT,
  @ConferenceParticipantID INT
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
 
      IF NOT EXISTS(
        SELECT *
        FROM WorkshopReservations
        WHERE @WorkshopReservationID = WorkshopReservationID
      )
        BEGIN
        ;THROW 60000, 'Given WorkshopReservationID does not exist', 1
      END
 
      IF NOT EXISTS(
        SELECT *
        FROM ConferenceParticipants
        WHERE @ConferenceParticipantID = ConferenceParticipantID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceParticipantID does not exist', 1
      END
 
      INSERT INTO dbo.WorkshopParticipants(WorkshopReservationID, ConferenceParticipantID)
        VALUES (@WorkshopReservationID, @ConferenceParticipantID)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding WorkshopParticipant: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
