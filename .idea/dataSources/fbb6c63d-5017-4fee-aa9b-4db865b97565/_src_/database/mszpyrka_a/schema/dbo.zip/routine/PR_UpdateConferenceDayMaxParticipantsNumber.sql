CREATE PROCEDURE dbo.PR_UpdateConferenceDayMaxParticipantsNumber
  @ConferenceDayID INT,
  @MaxParticipantsNumber INT
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY

      IF NOT EXISTS(
        SELECT *
        FROM ConferenceDays
        WHERE ConferenceDayID=@ConferenceDayID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceDayID does not exist', 1
      END
      UPDATE ConferenceDays
        SET MaxParticipantsNumber=@MaxParticipantsNumber WHERE ConferenceDayID=@ConferenceDayID
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while changing conference day maxParticipantsNumber : ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
