CREATE VIEW dbo.VI_UncompletedConfDayReservations
AS
  SELECT r.*, dbo.FN_GetConfDayReservationSignedParticipantsNumber(r.ConfDayReservationID) AS NumberOfSignedParticipants
  FROM ConfDayReservations r

  JOIN ConferenceDays cd
      ON cd.ConferenceDayID=r.ConferenceDayID
      AND dbo.FN_GetConfDayReservationSignedParticipantsNumber(r.ConfDayReservationID) < r.ParticipantsNumber
      AND GETDATE()>DATEADD(WEEK,-2,dbo.FN_GetConferenceStartDate(cd.ConferenceID))
GO
