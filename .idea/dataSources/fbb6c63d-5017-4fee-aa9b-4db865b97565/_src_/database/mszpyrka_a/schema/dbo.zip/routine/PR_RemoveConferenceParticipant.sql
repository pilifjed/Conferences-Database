CREATE PROCEDURE dbo.PR_RemoveConferenceParticipant
  @ConferenceParticipantID INT
AS
BEGIN
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM ConferenceParticipants
        WHERE ConferenceParticipantID=@ConferenceParticipantID
      )
      BEGIN
        ;THROW 61001, 'Given ConferenceParticipantID does not exist', 1
      END
      IF @ConferenceParticipantID IS NOT NULL
        BEGIN
          DELETE  FROM ConferenceParticipants
                  WHERE ConferenceParticipantID=@ConferenceParticipantID
        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while deleting conferenceParticipant: ' + ERROR_MESSAGE ();
      THROW 61000, @errorMsg, 1
    END CATCH
END
GO
