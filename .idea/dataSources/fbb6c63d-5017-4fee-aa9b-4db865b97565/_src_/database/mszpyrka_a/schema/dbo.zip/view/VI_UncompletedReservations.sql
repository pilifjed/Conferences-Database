CREATE VIEW dbo.VI_UncompletedReservations
AS
  SELECT r.*,'ConferenceDay' AS Cause
  FROM Reservations r
  WHERE r.ReservationID IN(SELECT uc.ReservationID
                           FROM VI_UncompletedConfDayReservations uc)
  UNION
  SELECT r.*,'Workshop' AS Cause
  FROM Reservations r
  WHERE r.ReservationID IN(SELECT cdr.ReservationID
                           FROM  ConfDayReservations cdr
                           WHERE cdr.ConfDayReservationID
                                 IN(SELECT uw.ConfDayReservationID
                                    FROM VI_UncompletedWorkshopReservations uw))
GO
