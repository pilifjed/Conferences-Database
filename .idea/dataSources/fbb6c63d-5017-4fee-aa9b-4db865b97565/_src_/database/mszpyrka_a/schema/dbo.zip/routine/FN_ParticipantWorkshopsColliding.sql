CREATE FUNCTION dbo.FN_ParticipantWorkshopsColliding(@ParticipantID INT)
  RETURNS BIT
AS
BEGIN

  IF EXISTS(
    SELECT * FROM Participants AS p
    JOIN ConferenceParticipants AS cp1
      ON p.ParticipantID = cp1.ParticipantID AND p.ParticipantID = @ParticipantID
    JOIN ConferenceParticipants AS cp2
      ON p.ParticipantID = cp2.ParticipantID AND cp1.ConferenceParticipantID <> cp2.ConferenceParticipantID
    JOIN WorkshopParticipants AS wp1
      ON cp1.ConferenceParticipantID = wp1.ConferenceParticipantID
    JOIN WorkshopParticipants AS wp2
      ON cp2.ConferenceParticipantID = wp2.ConferenceParticipantID
    JOIN WorkshopReservations AS wr1
      ON wp1.WorkshopReservationID = wr1.WorkshopReservationID
    JOIN WorkshopReservations AS wr2
      ON wp2.WorkshopReservationID = wr2.WorkshopReservationID
    WHERE dbo.FN_WorkshopsColliding (wr1.WorkshopID, wr2.WorkshopID) = 1
  )
  RETURN 1

  RETURN 0

END
GO
