CREATE PROCEDURE dbo.PR_AddConfDayReservation
  @ReservationID INT,
  @ConferenceDayID INT,
  @ParticipantsNumber INT,
  @StudentsNumber INT
AS
BEGIN
    SET NOCOUNT OFF
    BEGIN TRY
      IF NOT EXISTS(
        SELECT *
        FROM Reservations
        WHERE @ReservationID = ReservationID
      )
      BEGIN
        ;THROW 60000, 'Given ReservationID does not exist', 1
      END

      IF NOT EXISTS(
        SELECT *
        FROM ConferenceDays
        WHERE @ConferenceDayID = ConferenceDayID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceDayID does not exist', 1
      END

      INSERT INTO dbo.ConfDayReservations(ReservationID, ConferenceDayID, ParticipantsNumber, StudentsNumber)
        VALUES (@ReservationID, @ConferenceDayID, @ParticipantsNumber, @StudentsNumber)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding confDayReservation: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
