CREATE TRIGGER TR_ConfDayReservations_NotEnoughPlaces
ON dbo.ConfDayReservations
  AFTER INSERT, UPDATE
AS
BEGIN
  IF EXISTS(
    SELECT *
    FROM ConfDayReservations
    WHERE dbo.FN_GetConfDayFreePlaces(ConferenceDayID) < 0
  )
  BEGIN
    ROLLBACK
    ;THROW 60000, 'Not enough free places for given ConferenceDayID', 1
  END
END
GO
