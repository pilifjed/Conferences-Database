CREATE TRIGGER dbo.TR_ConferenceParticipants_CancelledReservation
  ON dbo.ConferenceParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM inserted
    JOIN ConfDayReservations AS cdr
      ON inserted.ConfDayReservationID = cdr.ConfDayReservationID
    WHERE cdr.IsCancelled = 1
  )
  BEGIN

    ROLLBACK 
    ;THROW 60000, 'Cannot add new participant to cancelled ConfDayReservation', 1

  END

END
GO
