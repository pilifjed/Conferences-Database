CREATE PROCEDURE dbo.PR_AddConferenceParticipant
  @ConfDayReservationID INT,
  @ParticipantID INT,
  @StudentCardID CHAR(6)
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
      IF NOT EXISTS(
        SELECT * FROM ConfDayReservations WHERE @ConfDayReservationID=ConfDayReservationID
      ) BEGIN
          ;THROW 54321, 'Given ConfDayReservationID does not exist', 1
        END
      IF NOT EXISTS(
        SELECT * FROM Participants WHERE @ParticipantID=ParticipantID
      ) BEGIN
          ;THROW 54321, 'Given ParticipantID does not exist', 1
        END
      INSERT INTO ConferenceParticipants (ConfDayReservationID, ParticipantID, StudentCardID)
        VALUES (@ConfDayReservationID, @ParticipantID, @StudentCardID)
    END TRY
    BEGIN CATCH
      DECLARE @errormsg NVARCHAR(2048)
      = 'An error ocurred while adding conferenceParticipant. Error message: ' + ERROR_MESSAGE();
      ;THROW 52000, @errormsg, 1
    END CATCH
END
GO
