CREATE PROCEDURE dbo.PR_AddPayments
  @ReservationID INT,
  @PaymentDate DATE,
  @AmmountPaid MONEY
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
      IF NOT EXISTS(
        SELECT * FROM Reservations WHERE ReservationID=@ReservationID
      )
      BEGIN
        ;THROW 54321, 'Given ReservationID does not exist', 1
      END
      INSERT INTO Payments (ReservationID, PaymentDate, AmmountPaid)
        VALUES (@ReservationID, @PaymentDate, @AmmountPaid)
    END TRY
    BEGIN CATCH
      DECLARE @errormsg NVARCHAR(2048)
      = 'An error occurred while adding payment: ' + ERROR_MESSAGE();
      ;THROW 52000, @errormsg, 1
    END CATCH
END
GO
