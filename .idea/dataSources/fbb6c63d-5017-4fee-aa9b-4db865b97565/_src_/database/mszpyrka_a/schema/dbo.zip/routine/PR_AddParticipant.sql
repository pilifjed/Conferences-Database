CREATE PROCEDURE dbo.PR_AddParticipant
  @FirstName NVARCHAR(40),
  @LastName NVARCHAR(40),
  @PESEL CHAR(11)
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
      INSERT INTO Participants (FirstName, LastName, PESEL)
        VALUES (@FirstName, @LastName, @PESEL)
    END TRY
    BEGIN CATCH
      DECLARE @errormsg NVARCHAR(2048)
      = 'An error ocurred while adding participant. Error message: ' + ERROR_MESSAGE();
      ;THROW 52000, @errormsg, 1
    END CATCH
END
GO
