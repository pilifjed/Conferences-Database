CREATE FUNCTION dbo.FN_GetConfDayFreePlaces(@ConferenceDayID INT)
  RETURNS INT
AS BEGIN

  DECLARE @BookedPlaces INT = isnull(dbo.FN_GetConfDayBookedPlaces(@ConferenceDayID), 0)

  RETURN (
    SELECT MaxParticipantsNumber
    FROM ConferenceDays
    WHERE @ConferenceDayID = ConferenceDayID
  ) - @BookedPlaces

END
GO
