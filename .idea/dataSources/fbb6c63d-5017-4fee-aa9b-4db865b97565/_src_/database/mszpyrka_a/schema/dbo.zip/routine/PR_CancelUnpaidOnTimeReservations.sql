CREATE PROCEDURE dbo.PR_CancelUnpaidOnTimeReservations
AS
BEGIN
    BEGIN TRY
          UPDATE Reservations
            SET IsCancelled=1
          WHERE ReservationID
                IN( SELECT r.ReservationID
                    FROM Reservations r
                    WHERE DATEADD(WEEK,-1,GETDATE())>r.BookingDate) 
                AND ReservationID IN(SELECT ReservationID FROM VI_UnderpaidReservations)

          UPDATE ConfDayReservations
            SET IsCancelled=1
          WHERE ReservationID
                IN( SELECT r.ReservationID
                    FROM Reservations r
                    WHERE DATEADD(WEEK,-1,GETDATE())>r.BookingDate)
                AND ReservationID IN(SELECT ReservationID FROM VI_UnderpaidReservations)

          UPDATE WorkshopReservations
            SET IsCancelled=1
          WHERE ConfDayReservationID
                IN (SELECT ConfDayReservationID
                    FROM ConfDayReservations
                    WHERE ReservationID
                          IN( SELECT r.ReservationID
                              FROM Reservations r
                              WHERE DATEADD(WEEK,-1,GETDATE())>r.BookingDate)
                          AND ReservationID IN(SELECT ReservationID FROM VI_UnderpaidReservations)
        )
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while cancelling reservation: ' + ERROR_MESSAGE ();
      THROW 61000, @errorMsg, 1
    END CATCH
END
GO
