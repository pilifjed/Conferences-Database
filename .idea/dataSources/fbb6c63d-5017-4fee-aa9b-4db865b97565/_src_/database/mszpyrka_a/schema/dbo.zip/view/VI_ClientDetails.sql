CREATE VIEW dbo.VI_ClientDetails
AS
  SELECT
    c.ClientID,
    c.Name,
    c.Country,
    c.City,
    c.PostalCode,
    c.Address,
    c.Phone,
    IIF(c.IsCompany=1,'Company','Individual') Type
  From Clients c
GO
