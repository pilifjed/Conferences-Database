CREATE FUNCTION dbo.FN_GetProperDayPriceID(@Date DATE, @ConferenceDayID INT)
  RETURNS INT
AS
BEGIN
  RETURN (
    SELECT TOP 1 DayPriceID
    FROM DayPrices
    WHERE @Date > StartDate AND @ConferenceDayID = ConferenceDayID
    ORDER BY StartDate DESC
  )
END
GO
