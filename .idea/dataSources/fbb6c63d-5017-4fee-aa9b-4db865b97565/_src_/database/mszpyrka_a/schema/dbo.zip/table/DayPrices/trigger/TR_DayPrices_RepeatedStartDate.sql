CREATE TRIGGER TR_DayPrices_RepeatedStartDate
ON dbo.DayPrices
  AFTER INSERT, UPDATE
AS
BEGIN
  IF EXISTS(
    SELECT count(*)
    FROM DayPrices
    GROUP BY StartDate, ConferenceDayID
    HAVING count(*) > 1
  )
  BEGIN
    ROLLBACK
    ;THROW 60000, 'Given StartDate already exists in DayPrices', 1
  END
END
GO
