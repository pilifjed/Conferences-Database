CREATE FUNCTION dbo.FN_WorkshopsColliding(@workshop1ID INT, @workshop2ID INT)
  RETURNS BIT
AS
BEGIN

  DECLARE @date1 DATE = (
    SELECT Date
    FROM ConferenceDays
    WHERE ConferenceDayID = (
      SELECT ConferenceDayID
      FROM Workshops
      WHERE WorkshopID = @workshop1ID
    )
  )

  DECLARE @date2 DATE = (
    SELECT Date
    FROM ConferenceDays
    WHERE ConferenceDayID = (
      SELECT ConferenceDayID
      FROM Workshops
      WHERE WorkshopID = @workshop2ID
    )
  )

  DECLARE @startTime1 TIME = (
    SELECT StartTime
    FROM Workshops
    WHERE @workshop1ID = WorkshopID
  )

  DECLARE @startTime2 TIME = (
    SELECT StartTime
    FROM Workshops
    WHERE @workshop2ID = WorkshopID
  )

  DECLARE @endTime1 TIME = (
    SELECT EndTime
    FROM Workshops
    WHERE @workshop1ID = WorkshopID
  )

  DECLARE @endTime2 TIME = (
    SELECT EndTime
    FROM Workshops
    WHERE @workshop2ID = WorkshopID
  )

  IF (
    @date1 = @date2
    AND (@startTime1 >= @startTime2 AND @startTime1 < @endTime2)
    OR (@startTime2 >= @startTime1 AND @startTime2 < @endTime1)
  )
  BEGIN 
    RETURN 1
  END
  
  RETURN 0
END
GO
