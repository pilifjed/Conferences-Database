CREATE TRIGGER TR_WorkshopParticipants_NoMoreFreePlaces
ON dbo.WorkshopParticipants
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM WorkshopReservations
    WHERE ParticipantsNumber < dbo.FN_GetWorkshopReservationSignedParticipantsNumber (WorkshopReservationID)
  )
  BEGIN

    ROLLBACK
    ;THROW 60000, 'No free places left for given WorkshopReservationID', 1

  END

END
GO
