CREATE VIEW dbo.VI_ConfDayRanking
AS
  SELECT c.*, (dbo.FN_GetConfDayBookedPlaces(c.ConferenceDayID)*100/c.MaxParticipantsNumber)AS Interest
  FROM dbo.ConferenceDays c
GO
