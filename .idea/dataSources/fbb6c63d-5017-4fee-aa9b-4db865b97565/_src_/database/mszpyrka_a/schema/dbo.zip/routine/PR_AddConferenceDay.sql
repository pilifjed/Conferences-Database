CREATE PROCEDURE dbo.PR_AddConferenceDay
  @ConferenceID INT,
  @Date DATE,
  @MaxParticipantsNumber INT
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY

      IF NOT EXISTS(
        SELECT *
        FROM Conferences
        WHERE @ConferenceID = ConferenceID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceID does not exist', 1
      END

      INSERT INTO dbo.ConferenceDays(ConferenceID, Date, MaxParticipantsNumber)
        VALUES (@ConferenceID, @Date, @MaxParticipantsNumber)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding conferenceDay: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
