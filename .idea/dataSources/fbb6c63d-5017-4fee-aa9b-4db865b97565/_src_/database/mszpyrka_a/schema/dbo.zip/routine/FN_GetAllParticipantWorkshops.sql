CREATE FUNCTION dbo.FN_GetAllParticipantWorkshops(@ParticipantID INT)
  RETURNS TABLE
AS
  RETURN (
      SELECT wr.WorkshopID
      FROM Participants AS p
      JOIN ConferenceParticipants AS cp
        ON p.ParticipantID = cp.ParticipantID
      JOIN WorkshopParticipants AS wp
        ON cp.ConferenceParticipantID = wp.ConferenceParticipantID
      JOIN WorkshopReservations AS wr
        ON wp.WorkshopReservationID = wr.WorkshopReservationID
      WHERE p.ParticipantID = 85188
  )
GO
