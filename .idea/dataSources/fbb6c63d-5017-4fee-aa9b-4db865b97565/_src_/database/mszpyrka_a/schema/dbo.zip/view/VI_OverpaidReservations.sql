CREATE VIEW dbo.VI_OverpaidReservations
AS
  SELECT r.*
  From Reservations r
  WHERE dbo.FN_GetReservationTotalPrice(ReservationID)<
        (SELECT ISNULL(SUM(p.AmmountPaid),0)
         FROM Payments p
         WHERE p.ReservationID=r.ReservationID)
GO
