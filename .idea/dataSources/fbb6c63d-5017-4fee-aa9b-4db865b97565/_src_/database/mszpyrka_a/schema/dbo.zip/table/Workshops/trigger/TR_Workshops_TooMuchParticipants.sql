CREATE TRIGGER TR_Workshops_TooMuchParticipants
  ON dbo.Workshops
  AFTER INSERT, UPDATE
AS
BEGIN

  IF EXISTS(
    SELECT *
    FROM ConferenceDays AS cd
    JOIN Workshops AS w
    ON cd.ConferenceDayID = w.ConferenceDayID
    WHERE cd.MaxParticipantsNumber < w.MaxParticipantsNumber
  )
  BEGIN

    ROLLBACK
    ;THROW 60000, 'MaxParticipantsNumber for workshop cannot be bigger than for ConferenceDay', 1
  END
END
GO
