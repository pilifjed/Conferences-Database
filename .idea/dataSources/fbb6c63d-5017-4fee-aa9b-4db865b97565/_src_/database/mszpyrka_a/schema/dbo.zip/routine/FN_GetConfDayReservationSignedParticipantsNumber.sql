CREATE FUNCTION FN_GetConfDayReservationSignedParticipantsNumber(@ConfDayReservationID INT)
  RETURNS INT
AS BEGIN

  RETURN (
    SELECT count(*)
    FROM (
      SELECT *
      FROM ConferenceParticipants
      WHERE @ConfDayReservationID = ConfDayReservationID
    ) t
  )

END
GO
