CREATE FUNCTION FN_GetConfDayReservationSignedStudentsNumber(@ConfDayReservationID INT)
  RETURNS INT
AS BEGIN

  RETURN (
    SELECT count(*)
    FROM (
      SELECT *
      FROM ConferenceParticipants
      WHERE @ConfDayReservationID = ConfDayReservationID AND StudentCardID IS NOT NULL
    ) t
  )

END
GO
