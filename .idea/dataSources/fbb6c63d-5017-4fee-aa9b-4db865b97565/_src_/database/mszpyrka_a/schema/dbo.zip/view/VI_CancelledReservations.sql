CREATE VIEW dbo.VI_CancelledReservations
AS
  SELECT r.*
  From Reservations r
  WHERE r.IsCancelled=1
GO
