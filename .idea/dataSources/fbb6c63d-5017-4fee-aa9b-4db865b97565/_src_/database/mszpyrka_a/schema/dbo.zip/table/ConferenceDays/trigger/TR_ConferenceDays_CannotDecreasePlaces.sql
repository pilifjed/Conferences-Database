CREATE TRIGGER TR_ConferenceDays_CannotDecreasePlaces
	ON dbo.ConferenceDays
	AFTER UPDATE
AS
BEGIN

	IF EXISTS(
		SELECT *
		FROM ConferenceDays
		WHERE dbo.FN_GetConfDayFreePlaces (ConferenceDayID) < 0
	)
	BEGIN
		ROLLBACK
		;THROW 60000, 'Registered participants number exceeds new places limit for updated ConferenceDay', 1
	END

END
GO
