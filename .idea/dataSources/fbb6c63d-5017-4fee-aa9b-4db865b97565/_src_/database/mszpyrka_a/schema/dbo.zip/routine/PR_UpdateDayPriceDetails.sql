CREATE PROCEDURE dbo.PR_UpdateDayPriceDetails
  @DayPriceID INT,
  @StartDate DATE,
  @Price MONEY,
  @StudentDiscount DECIMAL(3,2)
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY

      IF NOT EXISTS(
        SELECT *
        FROM DayPrices
        WHERE DayPriceID=@DayPriceID
      )
        BEGIN
        ;THROW 60000, 'Given DayPriceID does not exist', 1
      END
      IF @StartDate IS NOT NULL
        BEGIN
          UPDATE DayPrices
            SET StartDate = @StartDate WHERE DayPriceID=@DayPriceID
        END
      IF @Price IS NOT NULL
        BEGIN
          UPDATE DayPrices
            SET Price = @Price WHERE DayPriceID=@DayPriceID
        END
      IF @StudentDiscount IS NOT NULL
        BEGIN
          UPDATE DayPrices
            SET StudentDiscount = @StudentDiscount WHERE DayPriceID=@DayPriceID
        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while changing dayPrice details: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
