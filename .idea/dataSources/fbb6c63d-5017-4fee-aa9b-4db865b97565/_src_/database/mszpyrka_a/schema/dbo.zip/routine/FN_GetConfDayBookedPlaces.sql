CREATE FUNCTION FN_GetConfDayBookedPlaces(@ConferenceDayID INT)
  RETURNS INT
AS BEGIN

  RETURN isnull((
    SELECT sum(ParticipantsNumber)
    FROM ConfDayReservations
    WHERE @ConferenceDayID = ConferenceDayID AND IsCancelled = 0
  ), 0)

END
GO
