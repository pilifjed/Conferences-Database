CREATE PROCEDURE dbo.PR_AddWorkshop
  @ConferenceDayID INT,
  @WorkshopName NVARCHAR(120),
  @StartTime TIME,
  @EndTime TIME,
  @MaxParticipantsNumber INT,
  @Price MONEY
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY

      IF NOT EXISTS(
        SELECT *
        FROM ConferenceDays
        WHERE @ConferenceDayID = ConferenceDayID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceDayID does not exist', 1
      END

      INSERT INTO dbo.Workshops(ConferenceDayID, WorkshopName, StartTime, EndTime, MaxParticipantsNumber, Price)
        VALUES (@ConferenceDayID, @WorkshopName, @StartTime, @EndTime, @MaxParticipantsNumber, @Price)
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while adding workshop: ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
