CREATE FUNCTION dbo.FN_GetConferenceStartDate(@ConferenceID INT)
  RETURNS DATE
AS BEGIN
  RETURN (
    SELECT min(cd.Date)
    FROM ConferenceDays AS cd
    WHERE cd.ConferenceID = @ConferenceID
    GROUP BY cd.ConferenceID
  )
END
GO
