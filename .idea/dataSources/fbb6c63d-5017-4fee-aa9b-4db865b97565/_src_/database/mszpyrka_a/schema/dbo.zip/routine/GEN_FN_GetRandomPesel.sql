CREATE FUNCTION dbo.GEN_FN_GetRandomPesel(@randomFloat FLOAT)
  RETURNS char(11)
AS
BEGIN
  DECLARE @randomDec DECIMAL(12, 11) = convert(DECIMAL(12, 11), @randomFloat)
  DECLARE @counter INT = 11
  DECLARE @pesel CHAR(11) = ''

  WHILE(@counter > 0)
    BEGIN

      SET @randomDec = (@randomDec * 10) % 10
      SET @pesel = convert(char(1), convert(INT, @randomDec)) + @pesel
      SET @counter = @counter - 1

    END

  RETURN @pesel
END
GO
