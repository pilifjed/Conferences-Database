CREATE PROCEDURE dbo.PR_UpdateConferenceDetails
  @ConferenceID INT,
  @Name NVARCHAR(120),
  @Acronym NVARCHAR(15),
  @Country NVARCHAR(40),
  @City NVARCHAR(40),
  @Venue NVARCHAR(120)
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY

      IF NOT EXISTS(
        SELECT *
        FROM Conferences
        WHERE ConferenceID=@ConferenceID
      )
        BEGIN
        ;THROW 60000, 'Given ConferenceID does not exist', 1
      END
      IF @Name IS NOT NULL
        BEGIN
          UPDATE Conferences
            SET Name = @Name WHERE ConferenceID=@ConferenceID
        END
      IF @Acronym IS NOT NULL
        BEGIN
          UPDATE Conferences
            SET Acronym = @Acronym WHERE ConferenceID=@ConferenceID
        END
      IF @Country IS NOT NULL
        BEGIN
          UPDATE Conferences
            SET Country = @Country WHERE ConferenceID=@ConferenceID
        END
      IF @City IS NOT NULL
        BEGIN
          UPDATE Conferences
            SET City = @City WHERE ConferenceID=@ConferenceID
        END
      IF @Venue IS NOT NULL
        BEGIN
          UPDATE Conferences
            SET Venue = @Venue WHERE ConferenceID=@ConferenceID
        END
    END TRY
    BEGIN CATCH
      DECLARE @errorMsg nvarchar (2048) = 'An error occurred while changing conference details : ' + ERROR_MESSAGE ();
      THROW 60000, @errorMsg, 1
    END CATCH
END
GO
