CREATE FUNCTION dbo.FN_GetWorkshopBookedPlaces(@WorkshopID INT)
  RETURNS INT
AS BEGIN

  RETURN isnull((
    SELECT sum(ParticipantsNumber)
    FROM WorkshopReservations
    WHERE @WorkshopID = WorkshopID AND IsCancelled = 0
  ), 0)

END
GO
