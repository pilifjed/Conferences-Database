CREATE TRIGGER dbo.TR_WorkshopReservations_NotEnoughPlaces
ON dbo.WorkshopReservations
  AFTER INSERT, UPDATE
AS
BEGIN
  IF EXISTS(
    SELECT *
    FROM WorkshopReservations
    WHERE dbo.FN_GetWorkshopFreePlaces(WorkshopID) < 0
  )
  BEGIN
    ROLLBACK
    ;THROW 60000, 'Not enough free places for given WorkshopID', 1
  END
END
GO
