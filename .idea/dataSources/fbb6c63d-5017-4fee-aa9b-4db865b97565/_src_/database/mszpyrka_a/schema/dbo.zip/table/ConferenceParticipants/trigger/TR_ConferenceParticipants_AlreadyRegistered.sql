CREATE TRIGGER TR_ConferenceParticipants_AlreadyRegistered
ON dbo.ConferenceParticipants
  AFTER INSERT, UPDATE
AS
BEGIN
  IF EXISTS(
    SELECT *
    FROM inserted 
    JOIN ConferenceParticipants AS cp 
      ON inserted.ParticipantID = cp.ParticipantID
         AND inserted.ConfDayReservationID = cp.ConfDayReservationID
         AND inserted.ConferenceParticipantID <> cp.ConferenceParticipantID
  )
  BEGIN 
    
    ROLLBACK 
    ;THROW 60000, 'Participant already registered for given ConfDayReservationID', 1
    
  END
END
GO
