CREATE PROCEDURE dbo.PR_AddClient
  @Country NVARCHAR(40),
  @City NVARCHAR(40),
  @Address NVARCHAR(120),
  @PostalCode NVARCHAR(10),
  @Phone VARCHAR(15),
  @Name NVARCHAR(120),
  @IsCompany BIT
AS
BEGIN
    SET NOCOUNT ON
    BEGIN TRY
      INSERT INTO Clients (Country, City, Address, PostalCode, Phone, IsCompany, Name)
        VALUES (@Country, @City, @Address, @PostalCode, @Phone, @IsCompany, @Name)
    END TRY
    BEGIN CATCH
      DECLARE @errormsg NVARCHAR(2048)
      = 'An error ocurred while adding conference. Error message: ' + ERROR_MESSAGE();
      ;THROW 52000, @errormsg, 1
    END CATCH
END
GO
