CREATE VIEW dbo.VI_UncompletedWorkshopReservations
AS
  SELECT r.*, r.ParticipantsNumber - dbo.FN_GetWorkshopReservationSignedParticipantsNumber(r.WorkshopReservationID) AS MissingParticipants
  FROM WorkshopReservations r
  JOIN ConfDayReservations cdr
      ON r.ConfDayReservationID=cdr.ConfDayReservationID
         AND dbo.FN_GetWorkshopReservationSignedParticipantsNumber(r.WorkshopReservationID) < r.ParticipantsNumber
  JOIN ConferenceDays cd
      ON cdr.ConferenceDayID=cd.ConferenceDayID AND GETDATE()>DATEADD(WEEK,-2,dbo.FN_GetConferenceStartDate(cd.ConferenceID))
GO
